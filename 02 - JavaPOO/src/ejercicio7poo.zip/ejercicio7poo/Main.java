package ejercicio7poo;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner  leer = new Scanner(System.in).useDelimiter("\n");
        ServicioPersona servicio = new ServicioPersona();
        
        Persona [] vector= new Persona [2];
        for (int i=0; i<2; i++){
            vector[i]= new Persona();
        }
        for (int i=0; i<2; i++){
            System.out.println("Ingrese un nombre");
            String nom = leer.next();
            System.out.println("Ingrese edad");
            int edad = leer.nextInt();
            System.out.println("Ingrese sexo");
            String sexo = leer.next();
            System.out.println("Ingrese altura");
            Double altura= leer.nextDouble();
            System.out.println("Ingrese peso");
            Double peso= leer.nextDouble();
            vector[i]=servicio.creaPersona(vector[i],nom, edad, sexo,altura,peso);
            System.out.println("-----------------NUEVA PERSONA-----------");
        }
        
        for (int i=0; i<2; i++){
            System.out.println(vector[i].toString());
            servicio.calcularIMC(vector[i]);
            System.out.println("Es mayor de edad?: " + servicio.esMayorDeEdad(vector[i]));
        }
        
        
        
        
        
        
        
            
       
              
//        System.out.println(p1.toString());
//        System.out.println(p2.toString());
//        System.out.println(p3.toString());
//        System.out.println(p4.toString());
    }

}
