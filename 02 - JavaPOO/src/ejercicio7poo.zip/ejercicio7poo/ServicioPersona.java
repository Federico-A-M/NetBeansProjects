package ejercicio7poo;

import static ejercicio7poo.Persona.leer;

public class ServicioPersona {
    public Persona creaPersona(Persona p, String nom, int edad, String sexo, Double altura, Double peso){
        p.setNombre(nom);
        p.setEdad(edad);    
        boolean ok = false;
        do{
            if (sexo.substring(0,1).equals("M")|| sexo.substring(0,1).equals("H") || sexo.substring(0,1).equals("O")){
                ok = true;
                break;
            }
            else{
                System.out.println(" no existe ese tipo de datos. Ingrese nuevamente el sexo");
                sexo = leer.next();
            }            
        }while(ok!=true);
        p.setSexo(sexo);
        p.setAltura(altura);
        p.setPeso(peso);
        return p;
    }
    
    public Integer calcularIMC(Persona p){
        Integer n= 0;
        double imc= (p.getPeso()/(Math.pow(p.getAltura(),2)));
        if(imc <20){
            n= -1;
            System.out.println("ESTAS FLAQUITO");
        }
        else{
            if(20<imc && imc<25){
                n= 0;
                System.out.println("ESTAS PASABLE");
            }
            else{
                n=1;
                System.out.println("Estas ");
            }
        }
        return n;
    }
    
    public Boolean esMayorDeEdad(Persona p){
        return (p.getEdad()>=18)?true:false;
    } 
    
        

    
    
}
